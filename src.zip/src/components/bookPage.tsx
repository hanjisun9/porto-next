import { ReactNode } from "react";

interface BookPageProps{
    id: string;
    front: ReactNode;
    back?: ReactNode;
    side?: "left" | "right";
}

export default function BookPage({id, front, back, side = "right"}: BookPageProps){
    return(
        <div className={`book-page page-${side}`} id={id}>
            <div className="page-front">{front}</div>
            {back && <div className="page-back">{back}</div>}
        </div>
    )
}